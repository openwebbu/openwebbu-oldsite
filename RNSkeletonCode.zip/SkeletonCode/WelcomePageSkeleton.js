import React, { Component } from 'react';
import { AppRegistry, StyleSheet, Text, View, Navigator, Image, Button } from 'react-native';

class WelcomePage extends Component {


  render() {
    return (

    )
  }


}



export default WelcomePage