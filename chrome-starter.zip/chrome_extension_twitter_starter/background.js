// Sends an alert popup screen with the alert() method
$(function() {
	alert();
});